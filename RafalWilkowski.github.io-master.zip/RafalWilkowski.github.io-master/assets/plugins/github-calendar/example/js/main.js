GitHubCalendar(".calendar-1", "IonicaBizau", {
    responsive: true,
    tooltips: true
});
